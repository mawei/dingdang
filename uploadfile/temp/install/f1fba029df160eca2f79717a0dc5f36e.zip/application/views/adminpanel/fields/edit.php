<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?><?php defined('BASEPATH') or exit('No permission resources.'); ?>
<form class="form-horizontal" role="form" id="validateform" name="validateform" action="<?php echo base_url('adminpanel/fields/edit')?>" >
	<div class='panel panel-default '>
		<div class='panel-heading'>
			<i class='fa fa-table'></i> 文档字段 修改信息
			<div class='panel-tools'>
				<div class='btn-group'>
					<a class="btn " href="<?php echo base_url('adminpanel/fields')?>"><span class="glyphicon glyphicon-arrow-left"></span> 返回 </a>
				</div>
			</div>
		</div>
		<div class='panel-body '>
								<fieldset>
						<legend>基本信息</legend>
													
	<div class="form-group">
				<label for="document_id" class="col-sm-2 control-label form-control-static">文档</label>
				<div class="col-md-5 ">
					<input class="form-control" value="<?php echo isset($data_info['document_id_text'])?$data_info['document_id_text']:''; ?>" readonly="readonly" placeholder="请点击选择" type="text" id="document_id_text"  /><input type="hidden" value="<?php echo isset($data_info['document_id'])?$data_info['document_id']:'';?>" id="document_id" name="document_id" />
				</div>
			</div>
													
	<div class="form-group">
				<label for="field_name" class="col-sm-2 control-label form-control-static">字段名称</label>
				<div class="col-sm-9 ">
					<input type="text" name="field_name"  id="field_name"  value='<?php echo isset($data_info['field_name'])?$data_info['field_name']:'' ?>'  class="form-control validate[required]"  placeholder="请输入字段名称" >
				</div>
			</div>
													
	<div class="form-group">
				<label for="field_alias" class="col-sm-2 control-label form-control-static">字段别称</label>
				<div class="col-sm-9 ">
					<input type="text" name="field_alias"  id="field_alias"  value='<?php echo isset($data_info['field_alias'])?$data_info['field_alias']:'' ?>'  class="form-control validate[required]"  placeholder="请输入字段别称" >
				</div>
			</div>
													
	<div class="form-group">
				<label for="type" class="col-sm-2 control-label form-control-static">字段类型</label>
				<div class="col-sm-9 ">
					<input type="text" name="type"  id="type"  value='<?php echo isset($data_info['type'])?$data_info['type']:'' ?>'  class="form-control validate[required]"  placeholder="请输入字段类型" >
				</div>
			</div>
											</fieldset>
							<div class='form-actions'>
				<button class='btn btn-primary ' type='submit' id="dosubmit">保存</button>
			</div>
</form>
			<script language="javascript" type="text/javascript">
			var is_edit =<?php echo ($is_edit)?"true":"false" ?>;
			var id =<?php echo $id;?>;

			require(['<?php echo SITE_URL?>scripts/common.js'], function (common) {
		        require(['<?php echo SITE_URL?>scripts/adminpanel/fields/edit.js']);
		    });
		</script>
	
	